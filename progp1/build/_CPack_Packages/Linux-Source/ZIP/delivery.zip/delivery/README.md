
# Trabalho de programação

## Grupo

- up201307718 - Ivo Daniel Loureiro Casal Ribeiro

- up201907004 - Joao Margato Borlido Pereira

## Tarefas realizadas
- 20/12/2021 - Todos os testes estao a passar, nada nos sanitizers, documentaçao feita


